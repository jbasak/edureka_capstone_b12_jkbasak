from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    qdrant_url: str = "http://localhost:6333"
    qdrant_collection: str = "procurement_documents"
    llm_api_key: str = ""
    llm_base_url: str | None = None
    llm_model: str = ""
    llm_temperature: float = 0
    embedding_api_key: str = ""
    embedding_base_url: str | None = None
    embedding_model: str = ""
    embedding_dimension: int = 1536
    retrieval_top_k: int = 5
    retrieval_min_score: float = 0.25
    max_context_chars: int = 18000
    max_agent_iterations: int = 2
    max_file_size_mb: int = 20
    upload_dir: str = "/tmp/procurement-uploads"

@lru_cache
def settings():
    return Settings()
