import pytest
from app.models.core import ChatRequest

def test_question_validation():
    with pytest.raises(Exception):
        ChatRequest(question="x")
    assert ChatRequest(question="Which vendor is cheaper?").question
