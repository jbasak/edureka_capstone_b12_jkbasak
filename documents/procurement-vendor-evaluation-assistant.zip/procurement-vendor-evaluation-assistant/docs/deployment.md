# Deployment

```bash
docker compose up --build
```

For production:
- add authentication/authorization
- use a secret manager
- enable TLS
- persist and back up Qdrant
- pin dependency/image versions
- scan images
- add metrics/log aggregation
- configure resource limits
- use tenant/document access controls
