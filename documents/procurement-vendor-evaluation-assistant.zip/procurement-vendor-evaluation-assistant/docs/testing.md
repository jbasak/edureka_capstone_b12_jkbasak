# Testing

Run `pytest`.

Required future additions:
- parser tests for PDF/CSV/XLSX
- Qdrant integration tests
- mocked LLM/embedding tests
- end-to-end upload/query tests
- retrieval Recall@K
- citation correctness
- groundedness
- no-evidence accuracy
- prompt-injection regression tests
