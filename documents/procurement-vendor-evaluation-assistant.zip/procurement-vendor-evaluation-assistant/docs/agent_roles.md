# Agent Roles

**Planner:** identifies intent and retrieval queries.

**Retriever:** searches Qdrant using semantic embeddings.

**Reasoner:** synthesizes only retrieved evidence and cites sources.

**Validator:** rejects unsupported claims and invalid citations.

Keep agent iteration bounded to avoid loops.
