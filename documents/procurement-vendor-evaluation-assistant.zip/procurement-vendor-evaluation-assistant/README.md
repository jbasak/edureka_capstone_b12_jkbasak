# Procurement / Vendor Evaluation Assistant

Agentic RAG reference implementation for procurement teams comparing vendor proposals, contracts, pricing sheets, and requirements.

## Workflow

```text
Documents -> Parser -> Chunker -> Embeddings -> Qdrant
                                           ^
                                           |
Question -> Planner -> Retriever -> Reasoner -> Validator -> Answer + Sources
```

## Stack

- Python 3.11
- FastAPI
- Qdrant
- OpenAI-compatible LLM/embedding APIs
- PyMuPDF
- pandas/openpyxl
- Pydantic
- pytest
- Docker Compose

## Run

```bash
cp .env.example .env
# configure LLM_MODEL, LLM_API_KEY, EMBEDDING_MODEL, EMBEDDING_API_KEY
docker compose up --build
```

API: http://localhost:8000/docs

Upload:

```bash
curl -X POST http://localhost:8000/documents -F "file=@data/sample/acme_proposal.txt"
```

Ask:

```bash
curl -X POST http://localhost:8000/chat   -H "Content-Type: application/json"   -d '{"question":"Which vendor satisfies all mandatory requirements?"}'
```

Tests:

```bash
pip install -e '.[dev]'
pytest
```

The assistant is decision support. It must not approve purchases, sign contracts, or fabricate vendor facts.
