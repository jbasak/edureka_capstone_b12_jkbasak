from pydantic import BaseModel, Field

class Chunk(BaseModel):
    chunk_id: str
    document_id: str
    source_file: str
    file_type: str
    text: str
    metadata: dict = Field(default_factory=dict)

class Retrieved(Chunk):
    score: float

class ChatRequest(BaseModel):
    question: str = Field(min_length=3, max_length=5000)

class ChatResponse(BaseModel):
    answer: str
    grounded: bool
    sources: list[dict] = Field(default_factory=list)
    validation: dict = Field(default_factory=dict)
