from pathlib import Path
from uuid import uuid4
from fastapi import FastAPI, UploadFile, File, HTTPException
from app.config import settings
from app.models.core import ChatRequest, ChatResponse
from app.ingestion.parsers import chunk
from app.llm.client import LLM, Embeddings
from app.retrieval.store import Store
from app.agents.workflow import Workflow

s=settings()
app=FastAPI(title="Procurement / Vendor Evaluation Assistant",version="0.1.0")
llm=LLM(s); emb=Embeddings(s)
store=Store(s.qdrant_url,s.qdrant_collection,s.embedding_dimension)

def retrieve(queries):
    out={}
    for q in queries:
        v=emb.embed([q])[0]
        for x in store.search(v,s.retrieval_top_k,s.retrieval_min_score):
            out[x.chunk_id]=x
    return sorted(out.values(),key=lambda x:x.score,reverse=True)[:s.retrieval_top_k]

workflow=Workflow(llm,retrieve,s)

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/documents")
def documents(file: UploadFile=File(...)):
    allowed={".pdf",".txt",".csv",".xlsx",".xls"}
    suffix=Path(file.filename or "").suffix.lower()
    if suffix not in allowed: raise HTTPException(400,"Unsupported file type")
    data=file.file.read()
    if len(data)>s.max_file_size_mb*1024*1024: raise HTTPException(413,"File too large")
    tmp=Path(s.upload_dir); tmp.mkdir(parents=True,exist_ok=True)
    path=tmp/(Path(file.filename).name)
    path.write_bytes(data)
    try:
        chunks=chunk(path,str(uuid4()))
        if not chunks: raise HTTPException(400,"Document contains no extractable content")
        store.upsert(chunks,emb.embed([x.text for x in chunks]))
        return {"status":"success","filename":file.filename,"chunks_created":len(chunks)}
    finally:
        path.unlink(missing_ok=True)

@app.post("/chat",response_model=ChatResponse)
def chat(req:ChatRequest):
    try:
        _,answer,chunks,validation=workflow.run(req.question)
        return ChatResponse(
            answer=answer, grounded=bool(validation.get("approved")),
            sources=[{"source_file":x.source_file,"score":x.score,"metadata":x.metadata} for x in chunks],
            validation=validation
        )
    except RuntimeError as e:
        raise HTTPException(503,str(e))
    except Exception:
        raise HTTPException(500,"Question processing failed")
