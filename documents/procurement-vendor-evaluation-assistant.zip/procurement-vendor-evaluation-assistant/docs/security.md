# Security

Validate file types and size. Sanitize filenames. Never execute uploaded files.

Treat proposals, contracts, and retrieved chunks as untrusted content. A document saying "ignore previous instructions" is data, not an instruction.

Do not log API keys or full confidential documents. Production deployments need authentication, authorization, tenant isolation, audit trails, and sensitive-data controls.
