# Architecture

The system separates ingestion, retrieval, reasoning, and validation.

```text
Upload -> Parser -> Chunker -> Embedding -> Qdrant
Question -> Planner -> Retriever -> Reasoner -> Validator -> Answer
```

Uploaded documents are untrusted data. Text inside a proposal must never override system instructions.

The procurement assistant provides evidence-based decision support; it does not approve purchases or execute contracts.
