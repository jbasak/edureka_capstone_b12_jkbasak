from openai import OpenAI
from app.config import Settings

class LLM:
    def __init__(self, s: Settings):
        self.s=s
        self.client=OpenAI(
            api_key=s.llm_api_key or "missing",
            base_url=s.llm_base_url or None
        ) if s.llm_model else None

    def complete(self, system, user):
        if not self.client:
            raise RuntimeError("LLM not configured")
        r=self.client.chat.completions.create(
            model=self.s.llm_model, temperature=self.s.llm_temperature,
            messages=[{"role":"system","content":system},{"role":"user","content":user}]
        )
        return r.choices[0].message.content or ""

class Embeddings:
    def __init__(self, s: Settings):
        self.s=s
        self.client=OpenAI(
            api_key=s.embedding_api_key or s.llm_api_key or "missing",
            base_url=s.embedding_base_url or s.llm_base_url or None
        ) if s.embedding_model else None

    def embed(self, texts):
        if not self.client:
            raise RuntimeError("Embeddings not configured")
        r=self.client.embeddings.create(model=self.s.embedding_model,input=texts)
        return [x.embedding for x in r.data]
