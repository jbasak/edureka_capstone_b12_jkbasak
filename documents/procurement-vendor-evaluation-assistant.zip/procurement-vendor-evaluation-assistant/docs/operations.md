# Operations

When a document changes, delete its old vectors, re-parse, re-chunk, re-embed, and re-index.

Record LLM model, embedding model, prompt version, chunk settings, top-K, and similarity threshold. Re-run the evaluation suite after changes.

Common issues:
- poor retrieval: inspect chunks, embeddings, queries, top-K and threshold
- LLM unavailable: check credentials/model
- Qdrant unavailable: check `docker compose logs qdrant`
