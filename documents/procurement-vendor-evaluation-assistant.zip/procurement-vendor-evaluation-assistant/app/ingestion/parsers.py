from pathlib import Path
import pandas as pd
import fitz
from app.models.core import Chunk

def parse(path: Path, document_id: str):
    ext = path.suffix.lower()
    if ext == ".pdf":
        doc = fitz.open(path)
        text = "\n\n".join(
            f"[Page {i}]\n{p.get_text('text')}" for i,p in enumerate(doc,1) if p.get_text("text").strip()
        )
        return text, "pdf", {"pages": len(doc)}
    if ext == ".txt":
        return path.read_text(encoding="utf-8", errors="replace"), "txt", {}
    if ext == ".csv":
        df = pd.read_csv(path)
        return rows_to_text(df), "csv", {"rows": len(df), "columns": list(df.columns)}
    if ext in {".xlsx", ".xls"}:
        sheets = pd.read_excel(path, sheet_name=None)
        text = "\n\n".join(f"[Sheet: {name}]\n{rows_to_text(df)}" for name,df in sheets.items())
        return text, "excel", {"sheets": list(sheets)}
    raise ValueError(f"Unsupported file type: {ext}")

def rows_to_text(df):
    return "\n".join(
        " | ".join(f"{c}: {row[c]}" for c in df.columns)
        for _,row in df.iterrows()
    )

def chunk(path: Path, document_id: str, size=4000, overlap=500):
    text, kind, meta = parse(path, document_id)
    text = " ".join(text.split())
    if not text:
        return []
    result=[]; start=0; index=0
    while start < len(text):
        end=min(start+size,len(text))
        result.append(Chunk(
            chunk_id=f"{document_id}-{index}",
            document_id=document_id, source_file=path.name,
            file_type=kind, text=text[start:end],
            metadata={**meta,"chunk_index":index}
        ))
        if end == len(text): break
        start=max(end-overlap,start+1); index += 1
    return result
