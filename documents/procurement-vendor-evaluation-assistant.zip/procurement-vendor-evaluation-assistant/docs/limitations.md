# Limitations

The baseline does not include OCR for scanned PDFs, authentication, authorization, formal audit trails, or autonomous procurement execution.

Complex PDF tables may extract imperfectly. LLM responses remain probabilistic. Production procurement use requires security, legal, privacy, access-control, and governance review.
