from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from app.models.core import Retrieved

class Store:
    def __init__(self,url,collection,dimension):
        self.c=QdrantClient(url=url); self.collection=collection
        if not any(x.name==collection for x in self.c.get_collections().collections):
            self.c.create_collection(
                collection_name=collection,
                vectors_config=VectorParams(size=dimension,distance=Distance.COSINE)
            )

    def upsert(self,chunks,vectors):
        self.c.upsert(collection_name=self.collection,points=[
            PointStruct(id=x.chunk_id,vector=v,payload=x.model_dump())
            for x,v in zip(chunks,vectors)
        ])

    def search(self,vector,limit,threshold):
        hits=self.c.query_points(
            collection_name=self.collection,query=vector,limit=limit,with_payload=True
        ).points
        return [
            Retrieved(**h.payload,score=float(h.score))
            for h in hits if h.score >= threshold
        ]
