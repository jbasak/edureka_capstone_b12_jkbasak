from pathlib import Path
from app.ingestion.parsers import chunk

def test_txt_chunk(tmp_path):
    p=tmp_path/"vendor.txt"
    p.write_text("Vendor A annual price is $100000.",encoding="utf-8")
    result=chunk(p,"doc1",size=20,overlap=5)
    assert result and result[0].document_id=="doc1"

def test_unsupported(tmp_path):
    p=tmp_path/"x.doc"; p.write_text("x")
    try: chunk(p,"doc")
    except ValueError: pass
    else: assert False
